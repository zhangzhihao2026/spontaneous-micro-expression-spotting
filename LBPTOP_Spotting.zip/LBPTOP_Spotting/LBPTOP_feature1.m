clc;
clear;
PATH = '\';
Path   = '\';
Subject = dir(Path);
for z = 3:length(Subject)
     Sequence = dir(strcat(Path, Subject(z).name));
     [sequencenum,~] = size(Sequence);
     for i = 3: sequencenum
          Image = dir(strcat(Path, Subject(z).name,'\',Sequence(i).name,'\','*.jpg'));
          [frames,~] = size(Image);
          TMatrix = zeros(64, 64, 32);
          for j = 2: frames
               I = rgb2gray(imread(strcat(Path, Subject(z).name,'\',Sequence(i).name,'\',Image(j).name)));
               TMatrix(:,:,j) = I;
          end
           % LBP-TOP
           % parameter set
           FxRadius = 1; 
           FyRadius = 1;
           TInterval = 1;
           NeighborPoints = [8 8 8]; % XY, XT, and YT planes, respectively
           TimeLength = 1;
           BorderLength = 1;
           bBilinearInterpolation = 1;  % 0: not �� 1: bilinear interpolation
           %59 is only for neighboring points with 8. If won't compute uniform
           %patterns, please set it to 0, then basic LBP will be computed
           Bincount = 59;   %59 / 0
          
           if Bincount == 0
              Code = 0;
              nDim = 2 ^ (NeighborPoints(1));  %dimensionality of basic LBP
           else
              % uniform patterns for neighboring points with 8
              U8File = importdata('F:\Micro_Expression_Spotting_GLASTCNN\CASME2_Related\LBPTOP_Spotting\UniformLBP8.txt');
              BinNum = U8File(1, 1);
              nDim = U8File(1, 2); %dimensionality of uniform patterns
              Code = U8File(2 : end, :);
              clear U8File;
           end
           
           xGrid = 8; 
           height = floor(64/xGrid);
           yGrid = 8; 
           width = floor(64/yGrid);
           tGrid = 2;  
           length = floor(32/tGrid);
           
           Histogram_block = [];
           for x = 1: xGrid
                for y = 1: yGrid
                     for t = 1: tGrid
                          VolData = TMatrix(1+height*(x-1):height*x,1+width*(y-1):width*y,1+length*(t-1):length*t);
                          Histogram = LBPTOP(VolData, FxRadius, FyRadius, TInterval, ...
                          NeighborPoints, TimeLength, BorderLength, bBilinearInterpolation, Bincount, Code);
                          % [col,row] = size(B_Histogram1);
                          % 1 XY,2 XT,3 YT;
                          % B_Histogram = reshape(B_Histogram1',1,col*row);  %%% ����һ�� block ��ֱ��ͼ����
                          % Histogram(x,y,t,:) = B_Histogram;
                          Histogram_block = [Histogram_block, Histogram];
                     end
                end
           end
           if  ~exist(strcat(PATH,Subject(z).name))
                 mkdir(strcat(PATH,Subject(z).name));
           end
           save(strcat(PATH,Subject(z).name,'\',Sequence(i).name,'.mat'),'Histogram_block');
           clear TMatrix Histogram_block
     end
end