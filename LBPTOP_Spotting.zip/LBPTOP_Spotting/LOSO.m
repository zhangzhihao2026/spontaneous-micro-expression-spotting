function Conf_Mat = LOSO(histogram, label, subject)
             % This function calculates the recognition rate using Leave-One-Subject-Out cross validation.
             % --histogram:       size: m x c. m��������, c������ά��.
             % --label:               size: m x 1. 
             % --subject:           size: m x 1, indicating the subject id of each sample for loso.
    
             
             
              % -s=0:  svm_type : set type of SVM (default 0) 
                  % 0 -- C-SVC(multi-class classification)    
                  % 1 -- nu-SVC(multi-class classification)
	              % 2 -- one-class SVM	
                  % 3 -- epsilon-SVR (regression)       
                  % 4 -- nu-SVR		 (regression)
                                  
            % libsvm kernel_type: polynomial:  (gamma*u'*v + coef0)^degree
            % -t=1: kernel_type : set type of kernel function (default 2)
            % ������
	              % 0 -- linear: u'*v       
                  % 1 -- polynomial: (gamma*u'*v + coef0)^degree      
                  % 2 -- radial basis function: exp(-gamma*|u-v|^2)
	              % 3 -- sigmoid: tanh(gamma*u'*v + coef0)       
                  % 4 -- precomputed kernel (kernel values in training_set_file)
    
            % -c=1 cost : set the parameter C of C-SVC, epsilon-SVR, and nu-SVR (default 1)
            % -c = 1 C-SVC, epsilon-SVR, nu-SVR �ĳͷ�ϵ��
    
            % -d=3 degree : set degree in kernel function (default 3)
            % -r=0 coef0 : set coef0 in kernel function (default 0)
            % -g gamma : set gamma in kernel function (default 1/num_features)
            g =  1/22656; 
            % -n nu : set the parameter nu of nu-SVC, one-class SVM, and nu-SVR (default 0.5)
    
            % -p epsilon : set the epsilon in loss function of epsilon-SVR (default 0.1)
   
            % -m cachesize : set cache memory size in MB (default 100)
            % -e=0.000001 epsilon : set tolerance of termination criterion (default 0.001)
    
            % -h shrinking : whether to use the shrinking heuristics, 0 or 1 (default 1)
            % -b probability_estimates : whether to train a SVC or SVR model for probability estimates, 0 or 1 (default 0)
            % -wi weight : set the parameter C of class i to weight*C, for C-SVC (default 1)
            % -v n: n-fold cross validation mode
            % -q : quiet mode (no outputs)
    
            % --Rate:      Recognition rate of LOSO cross valiadation.
            
            nSamples = size(histogram,1);
            subject_set = unique(subject);             
            subject_number = size(subject_set,1); 
            conf_mat = zeros(2, 2, subject_number);
            % LOSO loop
            for p = 1 : subject_number
                 ind_Test = find( subject == subject_set(p,1));   
                 ind = 1:nSamples;
                 ind_Train = setdiff(ind,ind_Test);     
                 fea_Train = histogram(ind_Train, :); 
                 gnd_Train = label(ind_Train);
        
                 fea_Test = histogram(ind_Test, :);
                 gnd_Test = label(ind_Test);

                 % svm training/prediction using a linear kernel
                 model = svmtrain(gnd_Train, fea_Train, ['-s 0 -t 0 -c 1 -d 3 -r 0 -g' num2str(g) ' -e 0.000001']);
                 [predict_label, ~, ~] = svmpredict(gnd_Test, fea_Test, model);
                 %%% svmpredict
                 % record the recognized number of each subject
                 % rates(p) = accuracy(1) / 100 * size(predict_label, 1);
                 % get total recognition rate
                 [confmat, ~] = confusionmat(gnd_Test, predict_label);                                               
                 conf_mat(:,:,p) = confmat;
            end
            Conf_Mat = sum(conf_mat, 3);
end