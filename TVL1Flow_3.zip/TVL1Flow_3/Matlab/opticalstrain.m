function optical_strain = opticalstrain(of_x, of_y)
% clc;
% clear all;

dx = 2;
dy = 2;
[m, n] = size(of_x);
e_xx = zeros(m, n);
e_yy = zeros(m, n);
e_x_y = zeros(m, n);
e_y_x = zeros(m, n);

for i = 1 : n
   if i <= dx
       e_xx(:, i) = (of_x(:, i+dx) - of_x(:, i)) / dx;
   elseif i > n-dx
       e_xx(:, i) = (of_x(:, i) - of_x(:, i-dx)) / dx;
   else
       e_xx(:, i) = (of_x(:, i+dx) - of_x(:, i-dx)) / (2*dx);
   end   
end

for i = 1 : m
   if i <= dy
       e_yy(i, :) = (of_y(i+dy, :) - of_y(i, :)) / dy;
   elseif i > n-dx
       e_yy(i, :) = (of_y(i, :) - of_y(i-dy, :)) / dy;
   else
       e_yy(i, :) = (of_y(i+dy, :) - of_y(i-dy, :)) / (2*dy);
   end   
end

for i = 1 : m
   if i <= dy
       e_x_y(i, :) = (of_x(i+dy, :) - of_x(i, :)) / dy;
   elseif i > n-dx
       e_x_y(i, :) = (of_x(i, :) - of_x(i-dy, :)) / dy;
   else
       e_x_y(i, :) = (of_x(i+dy, :) - of_x(i-dy, :)) / (2*dy);
   end   
end

for i = 1 : n
   if i <= dx
       e_y_x(:, i) = (of_y(:, i+dx) - of_y(:, i)) / dx;
   elseif i > n-dx
       e_y_x(:, i) = (of_y(:, i) - of_y(:, i-dx)) / dx;
   else
       e_y_x(:, i) = (of_y(:, i+dx) - of_y(:, i-dx)) / (2*dx);
   end   
end
e_xy = 0.5 * (e_x_y + e_y_x);

optical_strain = sqrt(e_xx.^2 + e_yy.^2 + 2 * e_xy.^2);

optical_strain = uint8(optical_strain);
end