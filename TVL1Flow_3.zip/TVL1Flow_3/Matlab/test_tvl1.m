a=double(imread('.\a.jpg'));
b=double(imread('.\b.jpg'));
out=tvl1(a,b);

U = out(:,:,1);
figure;
imshow(U);

V = out(:,:,2);
figure;
imshow(V);

imflow = flowToColor(out);
imflow=uint8(imflow);
figure;
imshow(imflow);

optical_strain = opticalstrain(U,V);
figure;
imshow(optical_strain);