clc;
clear;
Path = '\HOG3D_80\';  
ExpResult = [];

for k = 1:5
     subject = [];
     label = [];
     histogram_all = [];
          
     Subject = dir(Path);
     for z = 3: length(Subject)
          subnum = str2double(Subject(z).name(4:5)); %% 1 2 3 ....26
          
          Samples = dir(strcat(Path, Subject(z).name,'\','*.mat'));
          for i = 1: length(Samples)
               subject = [subject; subnum];
               point = strfind(Samples(i).name, '.');
               labelnum = 1 - str2double(Samples(i).name((point-k):(point-k)));
               label = [label; labelnum];
               %%% �Ա���0.1*kΪ��ǩ
               histogram = load(strcat(Path, Subject(z).name,'\', Samples(i).name));
               histogram = cell2mat(struct2cell(histogram));
               [d1,d2] = size(histogram);
               histogram = reshape(histogram,1,d1*d2); 
               histogram_all = [histogram_all; histogram];
          end
     end
    
     Conf_Mat = LOSO(histogram_all, label, subject);
     TP = Conf_Mat(1,1);
     FP = Conf_Mat(2,1);
     FN = Conf_Mat(1,2);
     TN = Conf_Mat(2,2);
     
     Sum = TP+FP+FN+TN;
     Acc = (TP+TN)/(Sum);
     Precision = TP/(TP+FP);  %%% �����ܴ�   Precision = 1/(1+ FP/TP) �� ��� FP/TP ������С
     Recall = TP/(TP+FN);       %%% �����ܴ�  Recall = 1/(1+ FN/TP)�� ��� FN/TP ������С
     F1_Score = 2/( (1/Precision)+(1/Recall) );
     expresult = [TP FP FN TN Sum Acc Precision Recall F1_Score];
     ExpResult = [ExpResult; expresult];
     clear subject label histogram_all
end
save(strcat('\ExpResult80.mat'), 'ExpResult');