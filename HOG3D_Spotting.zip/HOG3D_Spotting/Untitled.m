clc;
clear;
Num =[];
path = 'HOG3D_Feature_40\';
subject = dir(path);
for i =3:length(subject)
     mat = dir(strcat(path, subject(i).name, '\','*.mat'));
     for j = 1:length(mat)
          name = mat(j).name;
          point = strfind(name, '.');
          str = name((point-1):(point-1));
          num = str2double(str);
          Num = [Num; num];
     end
end
[col, ~] = size(Num);
NoM = zeros(col,1);
M = zeros(col,1);
for k = 1:col
     if Num(k,:)==0
         NoM(k,:) = 1;
     end
     if Num(k,:)==1
          M(k,:) = 1;
     end
end
have = sum(M);
not = sum(NoM);