clc; clear;
PATH = '\HOG3D_80\';
Path   = '\FaceWhole_80\';
Subject = dir(Path);
for z = 3:length(Subject)
     Sequence = dir(strcat(Path, Subject(z).name));
     [sequencenum,~] = size(Sequence);
     for i = 3: sequencenum
          Image = dir(strcat(Path, Subject(z).name,'\',Sequence(i).name,'\','*.jpg'));
          [frames,~] = size(Image);
          TMatrix = zeros(64, 64, 32);
          for j = 2: frames
               I = rgb2gray(imread(strcat(Path, Subject(z).name,'\',Sequence(i).name,'\',Image(j).name)));
               TMatrix(:,:,j) = I;
          end
           % hog3d feature
           xGrid = 8; 
           height = floor(64/xGrid);
           yGrid = 8; 
           width = floor(64/yGrid);
           tGrid = 2;  
           length = floor(32/tGrid);
           
           Histogram_block = [];
           for x = 1: xGrid
                for y = 1: yGrid
                     for t = 1: tGrid
                          VolData = TMatrix(1+height*(x-1):height*x,1+width*(y-1):width*y,1+length*(t-1):length*t);
                          Histogram = hog3d(VolData,1,1,1);
                          [s1,s2,s3,s4] =size(Histogram);
                          Histogram = reshape(Histogram, 1, s1*s2*s3*s4);
                          % [col,row] = size(B_Histogram1);
                          % 1 XY,2 XT,3 YT;
                          % B_Histogram = reshape(B_Histogram1',1,col*row);  %%% ����һ�� block ��ֱ��ͼ����
                          % Histogram(x,y,t,:) = B_Histogram;
                          Histogram_block = [Histogram_block, Histogram];
                     end
                end
           end
           
           if   ~exist(strcat(PATH,Subject(z).name))
                 mkdir(strcat(PATH,Subject(z).name));
           end
           save(strcat(PATH,Subject(z).name,'\',Sequence(i).name,'.mat'),'Histogram_block');
           clear TMatrix Histogram_block
     end
end