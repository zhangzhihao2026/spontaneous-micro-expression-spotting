# -*- coding: utf-8 -*-
from keras.layers import MaxPool3D,BatchNormalization,Reshape
from keras.layers import AveragePooling2D, GlobalAveragePooling2D
from keras.layers import Dense,Dropout,Conv3D,Input,Flatten,Activation
from keras.layers import maximum, Multiply, Concatenate, Add
from keras.regularizers import l2
from keras.models import Model
from keras.utils.vis_utils import plot_model



def c3d_lstcnn():
    
    weight_decay = 0.005
    
    ###### ------------------------------- eyeleft area -------------------------------------------------########
    input_of_eyeleft = Input(shape = (16, 16, 32, 3), 
                             dtype = 'float32', 
                             name = 'input_of_eyeleft')
    
    conv3d_1_eyeleft = Conv3D(32, (3, 3, 3), 
                              strides = (2, 2, 2), 
                              padding = 'same', 
                              kernel_regularizer = l2(weight_decay))(input_of_eyeleft)
    bn_1_eyeleft = BatchNormalization()(conv3d_1_eyeleft)
    act_1_eyeleft= Activation('relu')(bn_1_eyeleft)
    pool3d_1_eyeleft = MaxPool3D((2,2,4), strides=(2,2,4), padding='same')(act_1_eyeleft)
    
    conv3d_2_eyeleft = Conv3D(32, (3, 3, 3), 
                              strides = (2, 1, 1), 
                              padding = 'same', 
                              kernel_regularizer = l2(weight_decay))(pool3d_1_eyeleft)
    bn_2_eyeleft = BatchNormalization()(conv3d_2_eyeleft)
    act_2_eyeleft = Activation('relu')(bn_2_eyeleft)
    pool3d_2_eyeleft = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_2_eyeleft)
    ###### flatten_eyeleft = Flatten()(pool3d_2_eyeleft)
    ###### ------------------------------- --------------------------------------------------------------########
    
    ###### ------------------------------- eyeright area -------------------------------------------------########
    input_of_eyeright = Input(shape = (16, 16, 32, 3), 
                              dtype = 'float32', 
                              name = 'input_of_eyeright')
    
    conv3d_1_eyeright = Conv3D(32, (3, 3, 3), 
                               strides = (2, 2, 2), 
                               padding = 'same', 
                               kernel_regularizer = l2(weight_decay))(input_of_eyeright)
    bn_1_eyeright = BatchNormalization()(conv3d_1_eyeright)
    act_1_eyeright= Activation('relu')(bn_1_eyeright)
    pool3d_1_eyeright = MaxPool3D((2,2,4), strides=(2,2,4), padding='same')(act_1_eyeright)
    
    conv3d_2_eyeright = Conv3D(32, (3, 3, 3), 
                               strides = (2, 1, 1), 
                               padding = 'same', 
                               kernel_regularizer = l2(weight_decay))(pool3d_1_eyeright)
    bn_2_eyeright = BatchNormalization()(conv3d_2_eyeright)
    act_2_eyeright = Activation('relu')(bn_2_eyeright)
    pool3d_2_eyeright = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_2_eyeright)
    ###### ------------------------------- --------------------------------------------------------------########
    
    ###### ------------------------------- mouthleft area ----------------------------------------------########
    input_of_mouthleft = Input(shape = (16, 32, 32, 3), 
                               dtype = 'float32', 
                               name = 'input_of_mouthleft')
    
    conv3d_1_mouthleft = Conv3D(32, (3, 3, 3), 
                                strides = (2, 2, 2), 
                                padding = 'same', 
                                kernel_regularizer = l2(weight_decay))(input_of_mouthleft)
    bn_1_mouthleft = BatchNormalization()(conv3d_1_mouthleft)
    act_1_mouthleft= Activation('relu')(bn_1_mouthleft)
    pool3d_1_mouthleft = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_1_mouthleft)
    
    conv3d_2_mouthleft = Conv3D(32, (3, 3, 3), 
                                strides = (2, 2, 2), 
                                padding = 'same', 
                                kernel_regularizer = l2(weight_decay))(pool3d_1_mouthleft)
    bn_2_mouthleft = BatchNormalization()(conv3d_2_mouthleft)
    act_2_mouthleft = Activation('relu')(bn_2_mouthleft)
    pool3d_2_mouthleft = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_2_mouthleft)
    ###### ------------------------------- --------------------------------------------------------------########
    
    ###### ------------------------------- mouthright area ----------------------------------------------########
    input_of_mouthright = Input(shape = (16, 32, 32, 3), dtype = 'float32', name = 'input_of_mouthright')
    
    conv3d_1_mouthright = Conv3D(32, (3, 3, 3), 
                                 strides = (2, 2, 2), 
                                 padding = 'same', 
                                 kernel_regularizer = l2(weight_decay))(input_of_mouthright)
    bn_1_mouthright = BatchNormalization()(conv3d_1_mouthright)
    act_1_mouthright= Activation('relu')(bn_1_mouthright)
    pool3d_1_mouthright = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_1_mouthright)
    
    conv3d_2_mouthright = Conv3D(32, (3, 3, 3), 
                                 strides = (2, 2, 2), 
                                 padding = 'same', 
                                 kernel_regularizer = l2(weight_decay))(pool3d_1_mouthright)
    bn_2_mouthright = BatchNormalization()(conv3d_2_mouthright)
    act_2_mouthright = Activation('relu')(bn_2_mouthright)
    pool3d_2_mouthright = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_2_mouthright)
    
    ###### ------------------------------- --------------------------------------------------------------########
    local_feature = Concatenate(axis = 4)([pool3d_2_eyeleft, 
                                           pool3d_2_eyeright, 
                                           pool3d_2_mouthleft, 
                                           pool3d_2_mouthright])
    
    local_feature = Reshape((2, 2, 128))(local_feature)
    local_feature  = GlobalAveragePooling2D()(local_feature)
    outputs = Dense(2, activation='softmax', kernel_regularizer=l2(weight_decay))(local_feature)
    
    model = Model(inputs = [input_of_eyeleft, input_of_eyeright, input_of_mouthleft, input_of_mouthright], outputs = outputs, name="c3d_lstcnn")
    '''
    dense_local = Dense(128, activation='relu', kernel_regularizer=l2(weight_decay))(flatten_global_feature)
    dense_local = Dropout(0.5)(dense_local)
    
    ## Fl = Multiply()([Fl_G, Fl_H, Fl_V])
    ## Fl = Add()([Fl_G, Fl_H, Fl_V])
    '''
    return model