# -*- coding: utf-8 -*-
from keras.layers import AveragePooling2D, GlobalAveragePooling2D
from keras.layers import MaxPool3D,BatchNormalization,Reshape
from keras.layers import Dense,Dropout,Conv3D,Input,Flatten,Activation
from keras.layers import maximum, Multiply, Concatenate, Add
from keras.regularizers import l2
from keras.models import Model
from keras.utils.vis_utils import plot_model


def c3d_gstcnn():
    
    weight_decay = 0.005
    
    ###### ------------------------------- face area ----------------------------------------------------########
    input_of_face = Input(shape = (32, 64, 64, 3), 
                          dtype = 'float32', 
                          name = 'input_of_face')
    
    conv3d_1_face = Conv3D(32, (3, 3, 3), 
                           strides = (2, 2, 2), 
                           padding = 'same', 
                           kernel_regularizer = l2(weight_decay))(input_of_face)
    bn_1_face = BatchNormalization()(conv3d_1_face)
    act_1_face = Activation('relu')(bn_1_face)
    pool3d_1_face = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_1_face)
    ### print(K.int_shape(pool3d_1_Gray))
    
    conv3d_2_face = Conv3D(32, (3, 3, 3), 
                           strides = (1, 1, 1), 
                           padding = 'same', 
                           kernel_regularizer = l2(weight_decay))(pool3d_1_face)
    bn_2_face = BatchNormalization()(conv3d_2_face)
    act_2_face = Activation('relu')(bn_2_face)
    pool3d_2_face = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_2_face)
    
    conv3d_3_face = Conv3D(64, (3, 3, 3), 
                           strides = (1, 1, 1), 
                           padding = 'same', 
                           kernel_regularizer = l2(weight_decay))(pool3d_2_face)
    bn_3_face = BatchNormalization()(conv3d_3_face)
    act_3_face = Activation('relu')(bn_3_face)
    pool3d_3_face = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_3_face)
    
    conv3d_4_face = Conv3D(128, (3, 3, 3), 
                           strides = (1, 1, 1), 
                           padding = 'same', 
                           kernel_regularizer = l2(weight_decay))(pool3d_3_face)
    bn_4_face = BatchNormalization()(conv3d_4_face)
    act_4_face = Activation('relu')(bn_4_face)
    pool3d_4_face = MaxPool3D((2,2,2), strides=(2,2,2), padding='same')(act_4_face)
    
    global_feature = Reshape((2, 2, 128))(pool3d_4_face)
    global_feature = GlobalAveragePooling2D()(global_feature)
    '''
    dense_global = Dense(128, activation='relu', kernel_regularizer=l2(weight_decay))(flatten_global)
    dense_global = Dropout(0.5)(dense_global)
    dense_global = Dense(2, kernel_regularizer=l2(weight_decay))(global_feature)
    y_Predication = Activation('softmax')(dense_global)
    '''
    outputs = Dense(2, activation='softmax', kernel_regularizer=l2(weight_decay))(global_feature)
    
    ###### 此时是 128维度的向量
    ###### ------------------------------- --------------------------------------------------########
    ## Fl = Multiply()([Fl_G, Fl_H, Fl_V])
    ## Fl = Add()([Fl_G, Fl_H, Fl_V])
    '''
    x = Dense(256, kernel_regularizer=l2(weight_decay))(RGB_OF)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = Dropout(0.5)(x)
    '''
    '''
    X = Dense(2, kernel_regularizer=l2(weight_decay))(X)
    Predication = Activation('softmax')(X)
    #### 二分类使用 sigmoid函数，而不是 softmax 函数
    # Create model
    '''
    ##########x = Dense(256,activation='relu',kernel_regularizer=l2(weight_decay))(multi_area)
    ##########x = Dropout(0.5)(x)
    '''
    if summary:
        print(model.summary())
    return model
    # model = model.convert_model(model)
    '''
    
    '''
    with open('model_summary.txt', 'w') as f:
        with redirect_stdout(f):
            model.summary()
    '''
    ####### plot_model(model, to_file='./micro_expression model.png', show_shapes= True, show_layer_names=True)
    ####### 网络图在最后加入 model = c3d_early_model()
    model = Model(inputs = [input_of_face], outputs = outputs, name="c3d_gstcnn")
    return model